import java.lang.*;
import java.util.*;
import classes.*;
import fileio.*;
import java.io.*;


public class Start
 {
	public static void main(String args[])  throws Exception
	{
		Scanner sc = new Scanner(System.in);
		FoodZone f = new FoodZone();
		FileReadWriteDemo frwd = new FileReadWriteDemo();
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader bfr = new BufferedReader(isr);
		
		
		
		System.out.println("\n\n\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("\t\t\t-------------Welcome to Signature Food Zone-------------------");
		System.out.println("\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		
		
		boolean repeat=true;
		
		while(repeat)
		{
			System.out.println("Select your option:--------");
			System.out.println("\t1. Staff Management");
			System.out.println("\t2. Restaurant Management");
			System.out.println("\t3. Restaurant FoodItem Management");
			System.out.println("\t4. FoodItem Quantity Add-Sell");
			System.out.println("\t5. Exit");
						
			System.out.print("Enter you choice: ");
			int choice = sc.nextInt();
			
			switch(choice){
				
				

				case 1: 
										
					System.out.println("You have choose Staff Management");
											

					System.out.println("Select your option ");
					System.out.println("\t1. Insert New Staff");
					System.out.println("\t2. Remove Existing Staff");
					System.out.println("\t3. Show All Staffs");
					System.out.println("\t4. Search a Staff");
					System.out.println("\t5. Go Back");
											
					System.out.print("Select Your Choice: ");
					int option1 = sc.nextInt();

				switch(option1)
				{
				 case 1: 

					System.out.println("You have chose to Insert New Staff");					
					System.out.print("Staff  ID : ");
					String stId1 = sc.next();
					System.out.print("Staff Name : ");
					String name1 = sc.next();
					System.out.print("Staff Salary : ");
					double salary1 = sc.nextDouble();
					
					Staff s1 = new Staff(stId1, name1, salary1);

					if(f.insertStaff(s1))
					{
						System.out.println("Staff Inserted Successfully.");
						System.out.print("Name "+ name1+ ",  Id "+ stId1);
					}
					else{System.out.println("Staff can not be created now. Try again later");}

					break;
					
				 case 2 :

					System.out.println("You have chose to Remove Staff");
					System.out.print("Staff  ID: ");
					String stId2 = sc.next();

					Staff s2 = f.searchStaff(stId2);

					System.out.println("Are You surely want to delete this Staff? ");
					System.out.print("Press 1 to delete Staff  ");

					int delete = sc.nextInt();
					if(delete==1){
					if(s2 != null){
					if(f.removeStaff(s2))
					{
					 System.out.println("Staff ID " +stId2 +" Removed Successfully.");
					}
					else{System.out.println("Staff can not be removed now. Try again later");}
					}
					else{System.out.println("No Staff found.");}
					}
					else{System.out.println("Account is not deleted. Thanks for come back");}
						
					break;
			     case 3: 
				
					System.out.println("You have chose to Show All Staff");
					f.showAllStaffs();
					System.out.println("\n\n______________________________________\n\n");
					break;

				 case 4 :
	
		            System.out.println("You have chose to Search Staff");
					System.out.print("Staff  ID: ");
					String stId4 = sc.next();

					Staff s4 = f.searchStaff(stId4);

					if(s4!= null){
						
						System.out.println("Staff has been founded.");
						System.out.println("Staff ID : "+s4.getStId());
						System.out.println("Staff Name : "+s4.getName());
						System.out.println("Staff Salary : "+s4.getSalary());
						
					}
					else{System.out.println("No Staff found.");}

					break;

				 case 5: 
									
					System.out.println("Going Back to the main menu...............");
					break;

				default :

									
					System.out.println("Invalid option . Try again...............");
					break;
				}

				break;

				case 2:

						System.out.println("You have chose Restaurant Management");
						
						System.out.println("Select your option ");
						System.out.println("\t1. Insert New Restaurant");
						System.out.println("\t2. Remove Existing Restaurant");
						System.out.println("\t3. Show All Restaurants");
						System.out.println("\t4. Search a Restaurant");
						System.out.println("\t5. Go Back");
						
						System.out.print("Enter you option: ");
						int option2 = sc.nextInt();


						switch(option2)
						{
							case 1: 
							System.out.println("You have chose to Insert New Restaurant");
							
							System.out.print("Restaurant  ID: ");
							String rid1 = sc.next();
							System.out.print("Restaurant Name: ");
							String name1 = sc.next();

							Restaurant r1 = new Restaurant(rid1, name1);

							if(f.insertRestaurant(r1))
							{
								System.out.print("Restaurant Inserted Successfully.");
								System.out.print("Name "+ name1+ ",  Id  "+rid1);
							}
							else{System.out.println("Restaurant can not be created now. Try again later");}

							break;

							case 2 :

							System.out.println("You have chose to Remove Restaurant");
					
							System.out.print("Restaurant  ID: ");
							String rid2 = sc.next();

							Restaurant r2 = f.searchRestaurant(rid2);

							System.out.println("Are You sure you want to delete this Restaurant? ");
							System.out.print("Press 1 to delete Restaurant ");

							int delete = sc.nextInt();

							if(delete==1)
							{

								if(r2 != null)
								{
									if(f.removeRestaurant(r2))
									{
										System.out.print("Restaurant ID " + rid2+ " Removed Successfully.");
									}
									else
									{
										System.out.println("Restaurant can not be removed now. Try again later");
									}
								}
								else
								{
									System.out.println("No Restaurant found.");
								}
							}
							else{System.out.println("Account is not deleted. Thanks for come back");}
								
														
							break;
							
							
							case 3: 

							System.out.println("You have chose to Show All Restaurant");
							f.showAllRestaurants();

							break;

							case 4 :
	
							System.out.println("You have chose to Search Restaurant");
							
							System.out.print("Restaurant  ID: ");
							String rid4 = sc.next();

							Restaurant r4 = f.searchRestaurant(rid4);

							if(r4!= null)
							{
								System.out.println("Restaurant has been founded.");
								
								System.out.println("Restaurant ID : "+r4.getRid());
								System.out.println("Restaurant Name : "+r4.getName());
								
								r4.showAllFoodItems();
								
							}
							else{System.out.println("No Restaurant found.");}

							break;

							case 5: 
							
							System.out.println("Going Back to the main menu...............");
							
							break;

							default :
							
							System.out.println("Invalid option . Try again...............");
							
							break;
						}

					break;

				case 3: 
                        System.out.println("You have chose Restaurant Food Item Management");
						

						System.out.println("Select your option ");
						System.out.println("\t1. Insert New Food Item");
						System.out.println("\t2. Remove Existing Food Item");
						System.out.println("\t3. Show All Food Item");
						System.out.println("\t4. Search a Food Item");
						System.out.println("\t5. Go Back");
					
						System.out.print("Enter you choice: ");
						int option3 = sc.nextInt();


						switch(option3)
						{

							case 1: 
							System.out.println("You have choose to Insert New Food Items");
							System.out.print("Restaurant ID: ");
							String rid3 = sc.next();

							if(f.searchRestaurant(rid3) != null)
							{

								System.out.println("Which types of food do you want to insert ?");
								System.out.println("\t1. Main Dish");
								System.out.println("\t2. Starter");
								System.out.println("\t3. Go Back");
						
								System.out.print("Enter Food Type: ");
								int choice31 = sc.nextInt();

								switch(choice31)
								{
									case 1: 
										
									System.out.print("Food Id : ");
									String fid31 = sc.next();

									System.out.print("Food Name: ");
									String name31 = sc.next();

									System.out.print("Available Quantity : ");
									int availableQuantity31 = sc.nextInt();
					
									System.out.print("Food Price : ");
									double price31 = sc.nextDouble();
					
									System.out.print("Food Category : ");
									String category31 = sc.next();

									FoodItem Menu31= new MainDish(fid31,name31,availableQuantity31,price31,category31);
									
									if(f.searchRestaurant(rid3).insertFoodItem(Menu31))
									{
										System.out.println("Food Id Number "+ fid31 +" inserted for "+ rid3);
									}
									else
									{
										System.out.println("Food Item Can Not be inserted");
									}

									break;

									case 2 :
		
									System.out.print("Food Id : ");
									String fid32 = sc.next();

									System.out.print("Food Name: ");
									String name32 = sc.next();

									System.out.print("Available Quantity : ");
									int availableQuantity32 = sc.nextInt();
					
									System.out.print("Food Price : ");
									double price32 = sc.nextDouble();
					
									System.out.print("Food Size : ");
									String size32 = sc.next();

									FoodItem Menu32 = new Starter(fid32,name32, availableQuantity32,price32,size32 );

									if(f.searchRestaurant(rid3).insertFoodItem(Menu32))
									{
										System.out.println("Food Id Number "+ fid32 +" inserted for "+ rid3);
									}
									else
									{
										System.out.println("Food Item Can Not be inserted");
									}

									break;

									case 3: 
									
									System.out.println("Going Back to the main menu...............");
											
									break;

									default: 

									System.out.println("Invalid option . Try again...............");
									break;
									}
									
								}

								else{System.out.println("Id does not match. Try again.");}

								break;
	
					case 2 :

						System.out.println("You have choose to Remove Food Items");
						System.out.print("Restaurant ID: ");
						String rid222 = sc.next();

						if(f.searchRestaurant(rid222) != null)
						{
							Restaurant r22 = f.searchRestaurant(rid222);
							System.out.print("Food Item  ID: ");
							String fid22 = sc.next();

							FoodItem fm22 = r22.searchFoodItem(fid22);

							if(fm22!= null)
							{
								System.out.println("Are You sure you want to delete this Food Item? ");
								System.out.print("Press 1 to delete Food Item ");

								int delete = sc.nextInt();

								if(delete==1)
								{
									if(r22.removeFoodItem(fm22))
									{
										System.out.print("Food Item Removed Successfully.");
									}
									else
									{
										System.out.println("Food Item can not be removed now. Try again later");
									}
								}
							
								else
								{
									System.out.println("Account is not deleted. Thanks for come back");}
								}
							else{System.out.println("No Food Item found.");}
						}
						else
						{
							System.out.println("No Restaurant found.");
						}
						
						break;

				case 3: 
						System.out.println("You have chose to Show All Food Item");
						System.out.print("Restaurant  ID: ");
						String rid33 = sc.next();

						Restaurant r33 = f.searchRestaurant(rid33);

						if(f.searchRestaurant(rid33)!=null)
						{
						System.out.println("Restaurant has been founded.");
						r33.showAllFoodItems();
						}
						else{System.out.println("No Restaurant found.");
						}

						break;
			
				case 4 : 

						System.out.println("You have chose to Search Food Item");
						
						
						System.out.print("Restaurant ID: ");
						String rid44 = sc.next();

						if(f.searchRestaurant(rid44) != null){
						Restaurant r44 = f.searchRestaurant(rid44);
						System.out.print("Food Item  ID: ");
						String fid44 = sc.next();

						FoodItem fm44 = r44.searchFoodItem(fid44);

						if(fm44!= null)
						{
							System.out.println("FoodItem has been founded.");
							
							r44.showAllFoodItems();
							
						}
						else{System.out.println("No FoodItem found.");}
						}

						else{System.out.println("No Restaurant found.");}
						
						break;
								
				case 5: 
						
						System.out.println("Going Back to the main menu...............");
						break;

				default :

						System.out.println("Invalid option . Try again...............");
						break;
				}
				
				break;

					case 4 :
					
						System.out.println("You have chose FoodItem Quantity Add-Sell");
				        System.out.println("Select your option ");
						System.out.println("\t1. Add  Food Item");
						System.out.println("\t2. Sell  Food Item");
						System.out.println("\t3. Show Add Sell History");
						System.out.println("\t4. Go Back");
						
						System.out.print("Enter you choice: ");
						int option4 = sc.nextInt();
						
						switch(option4)
						{
							case 1: 
								
								System.out.println("You have chose to Add Food Item");
								
								System.out.print("Enter Restaurant ID: ");
								
								String rid41 = sc.next();

								if(f.searchRestaurant(rid41) != null)
								{

									System.out.print("Enter Food Item ID: ");
								
									String fid41 = sc.next();

									if(f.searchRestaurant(rid41).searchFoodItem(fid41) != null)
									{

										System.out.print("Added Food Items Quantity : ");
										int amount1 = sc.nextInt();
										if(f.searchRestaurant(rid41).searchFoodItem(fid41).addQuantity(amount1))
										{

										System.out.println("Food Amount Added ....");
										frwd.writeInFile("Amount : " +amount1 + "  added in "+ fid41+ " by "+ rid41);
										}
										else{System.out.println("Can Not Added");}
									}
									else{System.out.println("Invalid Food Item Id Number");}

								}
								else{System.out.println("Restaurant ID  does not MISMATCH");}
								
								break;

							case 2 : 
							
						        System.out.println("You have chose to Sell Food Item");
							    System.out.print("Enter Restaurant ID: ");
								
								String rid42 = sc.next();

								if(f.searchRestaurant(rid42) != null)
								{

									System.out.print("Enter Food Item ID: ");
								
									String fid42 = sc.next();

									if(f.searchRestaurant(rid42).searchFoodItem(fid42) != null)
									{

										System.out.print("Selled Food Item Quantity : ");
										int amount10 = sc.nextInt();
										if(f.searchRestaurant(rid42).searchFoodItem(fid42).sellQuantity(amount10))
										{

										System.out.println("Food Item Selled ....");
										frwd.writeInFile("Amount : " +amount10 + "Selled in "+ fid42+ " by "+ rid42);
										}
										else{System.out.println("Can Not Selled");}
									}
									else{System.out.println("Invalid Food Item Id Number");}

								}
								else{System.out.println("Restaurant ID  does not MISMATCH");}

								break;
							case 3: 
								System.out.println("You have chose to Show ADD SELL History");
								frwd.readFromFile();
								break;

							case 4 :
									
									
									System.out.println("Going Back to the main menu...............");
								
									

								break;

							default :

									
									
									System.out.println("Invalid option . Try again...............");
									
									


								break;
						}			

					break;
					
					case 5: 
						
						repeat=false;
						
						System.out.println("Thanks for being with us...............");
						
					break;

					default :

						System.out.println("Invalid option . Try again...............");
						
					break;

			}
		}
	}
}
	

