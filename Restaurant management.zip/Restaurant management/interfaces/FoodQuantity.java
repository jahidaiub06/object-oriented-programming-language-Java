package interfaces;

import classes.*;

public interface FoodQuantity{
	boolean addQuantity(int amount);
	boolean sellQuantity(int amount);
}