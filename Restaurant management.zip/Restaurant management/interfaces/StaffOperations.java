package interfaces;
import classes.*;

public interface StaffOperations{

	boolean insertStaff(Staff s);

	boolean removeStaff(Staff s);

	Staff searchStaff(String StId);

	void showAllStaffs();
}

