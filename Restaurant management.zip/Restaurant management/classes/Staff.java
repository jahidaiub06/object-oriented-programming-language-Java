package classes;
import java.lang.*;

public class Staff
{

	private String stId;
	private String name;
	private double salary;
	
	public Staff(){};
	public Staff( String stId ,String name,double salary)
	{
		this.stId = stId;
		this.name = name;
		this.salary = salary;
	}

	
	public void setStId(String stId){this.stId = stId;}
	public void setName(String name){this.name = name;}
	public void setSalary(double salary){this.salary = salary;}

	public String getStId(){return stId;} 
	public String getName(){return name;}
	public double getSalary(){return salary;} 
	
}
