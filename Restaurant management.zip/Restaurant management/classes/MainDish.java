package classes;
import java.lang.*;

public class MainDish extends FoodItem
{

  private String category;

  public MainDish()
		{
	    super();
		System.out.println("Main Dish");
		}

  public MainDish(String fid , String name,int availableQuantity, double price , String category )
  {
  	super(fid, name , availableQuantity, price);
  	this.category = category;
  }

  public void setCategory(String category)
  {
	  this.category = category;
  }
  public String getCategory()
  {
	  return category;
  }

  public void showInfo(){
    System.out.println("**********************************************");
    System.out.println("Food Id  : "+ getFid());
    System.out.println("Food Name  : "+ getName());
    System.out.println("Available Quantity  : "+ getAvailableQuantity());
    System.out.println("Food Price  : "+ getPrice());
  	System.out.println("Food Category  : "+ category);
    System.out.println("**********************************************");
  }

}