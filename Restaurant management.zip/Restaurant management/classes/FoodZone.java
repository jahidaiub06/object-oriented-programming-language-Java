package classes;

import java.lang.*;
import interfaces.*;

public class FoodZone implements RestaurantOperations, StaffOperations
{
	private Restaurant restaurants[] = new Restaurant[50];
	private Staff staffs[] = new Staff[100];

	public boolean insertRestaurant(Restaurant r){
		boolean flag = false;
		for(int i=0; i<restaurants.length; i++){
			if(restaurants[i] == null){
				restaurants[i] = r;
				flag = true;
				break;
			}
		}
		return flag;
	}

	public boolean removeRestaurant(Restaurant r){
		boolean flag = false;
		for(int i=0; i<restaurants.length; i++){
			if(restaurants[i] == r){
				restaurants[i] = null;
				flag = true;
				break;
			}
		}
		return flag;
	}

	public Restaurant searchRestaurant(String rid){

		Restaurant r = null;
		
		for(int i=0; i<restaurants.length; i++){
			if(restaurants[i] != null){
				if(restaurants[i].getRid().equals(rid)){
					r = restaurants[i];
					break;
				}
			}
		}
		return r;
	}

	public void showAllRestaurants(){
		for(int i = 0; i<restaurants.length; i++){
			if(restaurants[i]!=null){
				System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				System.out.println("Restaurant ID : "+restaurants[i].getRid());
				System.out.println("Restaurant Name : "+restaurants[i].getName());
				System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				restaurants[i].showAllFoodItems();
				System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			}
		}
	}


	public boolean insertStaff(Staff s){
		boolean flag = false;

		for(int i=0; i<staffs.length; i++){
			if(staffs[i]==null){
				staffs[i]=s;
				flag =  true;
				break;
			}
			else{flag = false;}
		}
		return flag;
	}

	public boolean removeStaff(Staff s){
		boolean flag = false;

		for(int i=0; i<staffs.length ; i++){
			if(staffs[i]==s){
				staffs[i]=null;
				flag =  true;
				break;
			}
			else{flag = false;}
		}
		return flag;
	}

	public Staff searchStaff(String stId){
		Staff s = null;
		for(int i=0; i<staffs.length ; i++){
			if(staffs[i] != null){
				if(staffs[i].getStId().equals(stId)){
					s=staffs[i];
					break;
				}
			}
		}
		return s;
	}

	public void showAllStaffs(){
		for(int i = 0; i<staffs.length; i++){
			if(staffs[i]!=null){
				System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				System.out.println("Staff ID : "+staffs[i].getStId());
				System.out.println("Staff Name : "+staffs[i].getName());
				System.out.println("Staff Salary : "+staffs[i].getSalary());
				System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			}
		}
	}


}